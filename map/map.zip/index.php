
<!DOCTYPE html>
<html>
<head>
    
    <link rel="icon" href="assets/img/logo.png">
    <title>Bantu saya Cari Lokasi</title>
	<meta name="viewport" content="initial-scale=1.0, user-scalable=no">
    <meta charset="utf-8">
	<link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
	<link rel="stylesheet" href="assets/css/style.css">
	<script src="assets/js/jquery-2.2.3.min.js"></script>
	<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAc_2KdYuzfhyG-kLubASMoZfjqSkjLOnA&libraries=geometrysensor=true"></script>
	<!-- 
	<script src="http://maps.google.com/maps/api/js?sensor=true&.js" ></script>
	 -->
	<script type="text/javascript" src="assets/js/gmaps.js"></script>
	
</head>
<body>
  			<div class="peta">
				<div id="map"></div>
			</div>
			<div class="tab_menu" lebar="0" data-toggle="tooltip" data-placement="left" title="Luaskan panel ke samping">
				<span class="glyphicon glyphicon-menu-left"></span>
			</div>
  			<div class="panel-cari">
				<div class="panel panel-default">
				  	<div class="panel-heading">
						<h3 class="panel-title">Bantu saya Cari Lokasi</h3>
				  	</div>
			  		<div class="panel-body">
						<form id="frmSetting">
						  	<div class="form-group">
								<label>Posisi Saya Sekarang:</label>
								<input type="text" class="form-control" id="posisiAwal" placeholder="Posisi Saya Sekarang" readonly>
						  	</div>
						  	<div class="form-group">
								<label>Cari Lokasi :</label>
								<select class="form-control" id="lokasi">
									<option value="ms">Masjid</option>
									<option value="rs">Rumah Sakit</option>
								</select>
							</div>
						  	<div class="form-group">
								<label>Cari <span class="lbl_lokasi">Masjid</span> dengan Radius:</label>
								<select class="form-control" id="radius" >
									<option value="50000">Semua</option>
									<option value="1000">1 Km</option>
									<option value="2000">2 Km</option>
									<option value="3000">3 Km</option>
									<option value="4000">4 Km</option>
									<option value="5000">5 Km</option>
								</select>
						  	</div>
						  	<div class="form-group">
								<label>Lokasi <span class="lbl_lokasi">Masjid</span> yang Saya Pilih: </label>
								<div class="load_combo">
									<select class="form-control" >
										<option value="">Pilih</option>
									</select>
								</div>
							</div>
				  			<button type="button" class="btn btn-primary" id="start_travel">Beri Saya Petunjuk</button>
				  			<input type="hidden" name="awal" id="posisiAwal1" readonly="true" />
				  			<input type="hidden" name="akhir" id="posisiTujuan" readonly="true" value="0"/>
						</form>
						<div id="instructions">
						</div>
			  		</div>
				</div>
			</div>
  	<script type="text/javascript">

  		var my_lat, my_lon, des_lat, des_lon;
		var map = new GMaps({
		  div: '#map',
		  lat: -12.043333,
		  lng: -77.028333,

		});
		init_location()
		
$(document).ready(function(){

	$('.tab_menu').hover(function(){
		$(this).tooltip('toggle');
	});

	$('.tab_menu').click(function(){
		var a = $(this).attr('lebar');
		if(a==0){
			$(this).html('<span class="glyphicon glyphicon-menu-right"></span>');
			$(this).attr('title', 'Ciutkan panel ke samping').tooltip('fixTitle');
			$(this).attr('lebar',1);
			$(this).css('right','400px');
			$('.panel-cari').css('width','400px');
		}else{
			$(this).html('<span class="glyphicon glyphicon-menu-left"></span>');
			$(this).attr('title', 'Luaskan panel ke samping').tooltip('fixTitle');
			
			$(this).attr('lebar',0);
			$(this).css('right','0');
			$('.panel-cari').css('width','0');
		}
	});

	$("#lokasi").change(function(){
		var type = $(this).val();
		var loc = $("#posisiAwal1").val();
		var rad = $("#radius").val();
		if(type=='ms'){
			$('.lbl_lokasi').html('Masjid');
			
		}else{
			$('.lbl_lokasi').html('Rumah Sakit');
			
		}
		$('.load_combo').load('combox_ajax.php?loc='+loc+'&rad='+rad+'&type='+type);
		$('.load_script').load('maker_ajax.php?loc='+loc+'&rad='+rad+'&type='+type);
		console.log('combox_ajax.php?loc='+loc+'&rad='+rad+'&type='+type);
		console.log('maker_ajax.php?loc='+loc+'&rad='+rad+'&type='+type);
	});

	$("#radius").change(function(){
		var type = $("#lokasi").val();
		var loc = $("#posisiAwal1").val();
		var rad = $(this).val();
		$('.load_combo').load('combox_ajax.php?loc='+loc+'&rad='+rad+'&type='+type);
		$('.load_script').load('maker_ajax.php?loc='+loc+'&rad='+rad+'&type='+type);
	});

	

	$('#start_travel').click(function(e){
		map.removeMarkers();
		var type = $("#lokasi").val();
		var my 	= $("#posisiAwal1").val();
		var mr = my.split(",");
		var des = $("#tempat").val();
		var nd = $("#tempat option:selected").text();
		var dr = des.split(",");
		$("#frmSetting").hide();
		$("#instructions").show();
		console.log(nd);
		init_location();

		map.addMarker({
            lat: dr[0],
            lng: dr[1],
            title: " "+nd+" ",
            animation : google.maps.Animation.DROP,
            icon: 'assets/img/'+type+'.png',
            infoWindow: {
                content: "<p>"+nd+"</p>"
            }
		});

		var mnt = 0;
		var jrk = 0;
		map.travelRoute({
		  	origin: [mr[0], mr[1]],
		  	destination: [dr[0], dr[1]],
		  	travelMode: 'driving',
		  	step: function(e) {
		    	$('#instructions').append('<p id="txt_ket"></p>');
		    	$('#instructions').append('<li>'+e.instructions+'</li>');
		    	$('#instructions li:eq(' + e.step_number + ')').delay(950 * e.step_number).fadeIn(200, function() {
			      	map.drawPolyline({
				        path: e.path,
				        strokeColor: '#00B3FD',
				        strokeOpacity: 0.6,
				        strokeWeight: 6
			      	});
			      	console.log(e.distance.value);
			      	mnt=mnt+e.duration.value;
			      	jrk=jrk+e.distance.value;
			      	console.log(e.duration.value);
			      	console.log(mnt+'  '+jrk);

		    	});

		  	}
		});
		setTimeout(function(){
			$('#instructions').append('<a href="index.php" class="btn btn-danger">Reset</a>');           
              
        }, 1000);

		
	});
});


		function init_location(){
			GMaps.geolocate({
		  	success: function(position) {
		    	map.setCenter(position.coords.latitude, position.coords.longitude);
		    	my_lat : position.coords.latitude;
		    	my_lon : position.coords.longitude;
		    	$("#posisiAwal1").val(position.coords.latitude+','+position.coords.longitude);
		    	map.addMarker({
				  lat: position.coords.latitude,
				  lng: position.coords.longitude,
				  title: 'My Position',
				  animation : google.maps.Animation.BOUNCE,
				  icon: 'assets/img/man.png',
				  infoWindow: {
					  	content: '<p>My Position</p>'
					}
				});
				GMaps.geocode({
				  	address: $('#posisiAwal1').val(),
				  	callback: function(results, status) {
				    	if (status == 'OK') {
				    		$("#posisiAwal").val(results[0].formatted_address);
				    	}
				  	}
				});
		  	},
		  	error: function(error) {
		    	alert('Geolocation failed: '+error.message);
		  	},
		  	not_supported: function() {
		    	alert("Your browser does not support geolocation");
		  	},
		  	always: function() {
		  	}
		});
		}
	</script>
	<div class="load_script"></div>

	<script src="assets/bootstrap/js/bootstrap.min.js"></script>
 
</body>
</html>